﻿using System;

namespace PizzaDeliveryApp.Models
{
    public class PizzaOrder
    {
        public int PepperoniQuantity { get; set; }
        public int VegetarianQuantity { get; set; }
        public double TotalToPay { get; set; }
        public DateTime DeliveryDateTime { get; set; }
    }
}
