﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using PizzaDeliveryApp.Pages;

namespace PizzaDeliveryApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            /*HomePage home = new HomePage();
            NavigationPage navigation = new NavigationPage(home);
            MainPage = navigation;
            */
            MainPage = new NavigationPage(new HomePage());
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
