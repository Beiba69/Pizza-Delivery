﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

using PizzaDeliveryApp.Models;

namespace PizzaDeliveryApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OrderPage : ContentPage
    {
        PizzaOrder order;

        public OrderPage()
        {
            InitializeComponent();

            order = new PizzaOrder();
        }

        private async void continueButton_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new OrderSummaryPage(order));
        }

        private void pepperoniStepper_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            order.PepperoniQuantity = (int)pepperoniStepper.Value;
            order.VegetarianQuantity = (int)vegetarianStepper.Value;
            order.TotalToPay = order.PepperoniQuantity * 12.05 + order.VegetarianQuantity * 7.23;

            totalLabel.Text = $"Total: {order.TotalToPay:C2}";
        }
    }
}