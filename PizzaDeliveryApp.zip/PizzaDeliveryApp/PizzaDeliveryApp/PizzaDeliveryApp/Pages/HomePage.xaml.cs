﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace PizzaDeliveryApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private async void orderButton_Clicked(object sender, EventArgs e)
        {
            OrderPage page = new OrderPage();
            await Navigation.PushAsync(page);

            //await Navigation.PushAsync(new OrderPage());
        }

        private async void aboutButton_Clicked(object sender, EventArgs e)
        {
            AboutPage page = new AboutPage();
            await Navigation.PushModalAsync(page);
        }
    }
}