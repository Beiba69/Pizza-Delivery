﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using PizzaDeliveryApp.Models;

using Xamarin.Essentials;

namespace PizzaDeliveryApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OrderSummaryPage : ContentPage
    {
        PizzaOrder summaryOrder;

        public OrderSummaryPage(PizzaOrder order)
        {
            InitializeComponent();

            summaryOrder = order;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            pepperoniCounter.Text = summaryOrder.PepperoniQuantity.ToString();
            vegetarianCounter.Text = summaryOrder.VegetarianQuantity.ToString();
            totalLabel.Text = summaryOrder.TotalToPay.ToString("C2");
        }

        private async void sendButton_Clicked(object sender, EventArgs e)
        {
            summaryOrder.DeliveryDateTime = orderDate.Date.Date;
            summaryOrder.DeliveryDateTime = summaryOrder.DeliveryDateTime.Add(orderTime.Time);

            SmsMessage message = new SmsMessage();
            message.Recipients = new List<string>() { "+527224269995" };
            message.Body = $"Your order is: \n{summaryOrder.PepperoniQuantity} pepperoni pizzas " +
                $"\n{summaryOrder.VegetarianQuantity} vegetarian pizzas " +
                $"\nTotal to pay: {summaryOrder.TotalToPay}" +
                $"\nAnd will be delivered on {summaryOrder.DeliveryDateTime.ToString("dddd, dd MMMM yyyy hh:mm:tt")}";

            await Sms.ComposeAsync(message);
        }
    }
}